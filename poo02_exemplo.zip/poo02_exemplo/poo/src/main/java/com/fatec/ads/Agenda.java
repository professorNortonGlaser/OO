package com.fatec.ads;

public class Agenda {
    String data;
    String hora;
    String medico;
    String paciente;

    public void consultar(){}
}
