package com.fatec.ads;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        int x =1;
        var p1 = new Paciente();
        p1.setCodigo(x++);
        p1.setNome("jose da silva");
        p1.setEmail("jose@norton.net.br");
        p1.mostrar();
        
        var p2 = new Paciente(x++, "maria souza","maria@norton.net.br");
        p2.mostrar();
        
        System.out.println( "Nome = "+ p1.getNome() );
    }
}
