package com.fatec.ads;

public class Exame {
    String consulta;
    String data;
    String descritivo;

    public void solicitar(){}
    public void consultar(){}

}
