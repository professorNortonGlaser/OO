package com.fatec.ads;

public class Medico {
    String nome;
    String crm;
    String telefone;
    String especialidade;
    String senha;

    public void acessar(){
        //TODO
    }
}
