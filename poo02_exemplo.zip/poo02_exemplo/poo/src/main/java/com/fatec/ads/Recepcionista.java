package com.fatec.ads;

public class Recepcionista {
    String nome;
    String cpf;
    String telefone;
    String senha;

    public void acessar(){};
}
