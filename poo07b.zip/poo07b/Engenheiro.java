
/**
 *
 * @author norton
 */
public class Engenheiro extends  Funcionario {
    private String especialidade;

    /**
     * @return the especialidade
     */
    public String getEspecialidade() {
        return especialidade;
    }

    /**
     * @param especialidade the especialidade to set
     */
    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }
}
