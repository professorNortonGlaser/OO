
/**
 *
 * @author norton
 */
public abstract class Funcionario {
    private double salarioBase;

    /**
     * @return the salarioBase
     */
    public double getSalarioBase() {
        return salarioBase;
    }

    /**
     * @param salarioBase the salarioBase to set
     */
    public void setSalarioBase(double salarioBase) {
        this.salarioBase = salarioBase;
    }
    
    public double calculoSalario(){
        return salarioBase;        
    }
    
    
}
