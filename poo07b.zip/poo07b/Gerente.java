
/**
 *
 * @author norton
 */
public class Gerente extends Funcionario {
    private double bonus;

    
    public double getBonus() {
        return bonus;
    }


    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    @Override
    public double calculoSalario(){        
        double salarioBase = super.calculoSalario();
        return salarioBase+getBonus();        
    }
    
            
            
}
