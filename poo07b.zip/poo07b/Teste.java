public class Teste {
    public static void main(String[] args) {
        Engenheiro e = new Engenheiro();
        e.setSalarioBase(10000);
        System.out.println(e.calculoSalario());

        Gerente g = new Gerente();
        g.setBonus(1000);
        g.setSalarioBase(10000);
        System.out.println(g.calculoSalario());

        Vendendor v = new Vendendor();
        v.setComissao(1000);
        v.setSalarioBase(2000);
        System.out.println(v.calculoSalario());
        System.out.println(v.calculoSalario(3000));
    }
}
