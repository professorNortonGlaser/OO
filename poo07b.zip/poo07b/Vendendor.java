
/**
 *
 * @author norton
 */
public class Vendendor extends Funcionario {
    private double comissao;

    public double getComissao() {
        return comissao;
    }

    public void setComissao(double comissao) {
        this.comissao = comissao;
    }
    
    @Override
    public double calculoSalario(){
        return getSalarioBase()+getComissao();        
    }
     //polimorfismo estatico
    public double calculoSalario(double premio){
        double salarioBase = super.calculoSalario();
        salarioBase += ((premio+this.comissao)/2); 
        return salarioBase;
    }
    
    
}
