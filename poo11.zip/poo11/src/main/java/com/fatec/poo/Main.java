package com.fatec.poo;

import com.fatec.poo.dao.ClienteDAO;

public class Main {
    public static void main(String[] args) {
        var dao = new ClienteDAO();
        var obj = new Cliente();
 
        obj.setDocumento("RG234234234");
        obj.setEmail("teste@norton.net.br");
        obj.setLogradouro("Rua frei joao, 59 são paulo");
        obj.setNome("norton");
        obj.setTelefone("2344-2344");

        var rows = dao.inserir(obj);
        System.out.println("Quantidade de registro afetados "+ rows);
        
        obj.setCodigo(1);
        obj.setEmail("norton@norton.net.br");
        dao.alterar(obj);

        var obj2 = dao.carregar(1);
        System.out.println("codigo="+ obj2.getCodigo() + ", nome="+ obj2.getNome() + "email="+obj2.getEmail() + ", telefone="+ obj2.getTelefone() + "Logradouro="+obj2.getLogradouro());


    }
}