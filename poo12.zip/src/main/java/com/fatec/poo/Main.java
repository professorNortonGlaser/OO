package com.fatec.poo;

import com.fatec.poo.view.*;

public class Main {
    public static void main(String[] args) {
       var tela = new FrmCliente();
       tela.setVisible(true);
    }
}