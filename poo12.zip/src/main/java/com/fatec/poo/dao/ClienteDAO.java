package com.fatec.poo.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.fatec.poo.Cliente;

public class ClienteDAO {
    private static final String URL = "jdbc:sqlite:exemplo.db";

    public ClienteDAO(){
        criarNovaTabela();
    }

    public int inserir(Cliente obj){
        String sql = "INSERT INTO cliente(nome, email,documento, telefone, logradouro) VALUES(?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, obj.getNome());
            pstmt.setString(2, obj.getEmail());
            pstmt.setString(3, obj.getDocumento());
            pstmt.setString(4, obj.getTelefone());
            pstmt.setString(5, obj.getLogradouro());
            return pstmt.executeUpdate();
        } catch (Exception e) {
            System.err.println("Erro ao inserir cliente: " + e.getMessage());
            return 0;
        }
    }


    public int alterar(Cliente obj){
        String sql = "update cliente set nome=?, email=?,documento=?, telefone=?, logradouro=? where codigo=?";
        try (Connection conn = DriverManager.getConnection(URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, obj.getNome());
            pstmt.setString(2, obj.getEmail());
            pstmt.setString(3, obj.getDocumento());
            pstmt.setString(4, obj.getTelefone());
            pstmt.setString(5, obj.getLogradouro());
            pstmt.setInt(6, obj.getCodigo());
            return pstmt.executeUpdate();
        } catch (Exception e) {
            System.err.println("Erro ao alterar cliente: " + e.getMessage());
            return 0;
        }
    }

    
    public int remover(Cliente obj){
        String sql = "delete from cliente where codigo=?";
        try (Connection conn = DriverManager.getConnection(URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, obj.getCodigo());
            return pstmt.executeUpdate();
        } catch (Exception e) {
            System.err.println("Erro ao remover cliente: " + e.getMessage());
            return 0;
        }
    }

    public void criarNovaTabela() {
        String sql = "CREATE TABLE IF NOT EXISTS cliente (\n"
                + " codigo integer PRIMARY KEY AUTOINCREMENT,\n"
                + " nome varchar(100) NOT NULL,\n"
                + " email varchar(100), documento varchar(30), telefone varchar(30), logradouro varchar(1000)"
                + ");";
        try (Connection conn = DriverManager.getConnection(URL);
             Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
            System.out.println("Tabela 'cliente' criada ou já existente.");
        } catch (Exception e) {
            System.err.println("Erro ao criar tabela: " + e.getMessage());
        }
    }

    public Cliente carregar(int codigo) {
        var obj = new Cliente();
        String sql = "SELECT * FROM cliente where codigo="+codigo;
        try (Connection conn = DriverManager.getConnection(URL);
            Statement stmt = conn.createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);
            System.out.println("\n--- Lista de Usuários ---");
            if(rs.next()) {
                obj.setCodigo(codigo);
                obj.setNome(rs.getString("nome"));
                obj.setDocumento(rs.getString("documento"));
                obj.setTelefone(rs.getString("telefone"));
                obj.setEmail(rs.getString("email"));
                obj.setLogradouro(rs.getString("logradouro"));
            }
        } catch (Exception e) {
            System.err.println("Erro ao listar usuários: " + e.getMessage());
        }
        return obj;
    }

    public List<Cliente> listar(int codigo) {
        List<Cliente> lista = new ArrayList<Cliente>();
        String sql = "SELECT * FROM cliente order by nome";
        try (Connection conn = DriverManager.getConnection(URL);
            Statement stmt = conn.createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);
            System.out.println("\n--- Lista de Usuários ---");
            while(rs.next()) {
                var obj = new Cliente();
                obj.setCodigo(rs.getInt("codigo"));
                obj.setNome(rs.getString("nome"));
                obj.setDocumento(rs.getString("documento"));
                obj.setTelefone(rs.getString("telefone"));
                obj.setEmail(rs.getString("email"));
                obj.setLogradouro(rs.getString("logradouro"));
                lista.add(obj);
            }
        } catch (Exception e) {
            System.err.println("Erro ao listar usuários: " + e.getMessage());
        }
        return lista;
    }


}
