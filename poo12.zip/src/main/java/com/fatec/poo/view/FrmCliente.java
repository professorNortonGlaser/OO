package com.fatec.poo.view;

import com.fatec.poo.Cliente;
import com.fatec.poo.dao.ClienteDAO;

import java.awt.GridLayout;
import java.awt.TrayIcon.MessageType;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class FrmCliente extends JFrame {

    private JTextField txtCodigo;
    private JTextField txtNome;
    private JTextField txtEmail;
    private JTextField txtDocumento;
    private JTextField txtTelefone;
    private JTextField txtLogradouro;

    private JButton btnConsultar;
    private JButton btnInserir;
    private JButton btnAlterar;
    private JButton btnExcluir;
    private JButton btnLimpar;
    private JButton btnListar;

    private ClienteDAO dao;

    public FrmCliente() {

        dao = new ClienteDAO();

        setTitle("Cadastro de Clientes");
        setSize(500, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel painel = new JPanel();
        painel.setLayout(new GridLayout(7, 2, 6, 6));

        painel.add(new JLabel("Código"));
        txtCodigo = new JTextField();
        painel.add(txtCodigo);

        painel.add(new JLabel("Nome"));
        txtNome = new JTextField();
        painel.add(txtNome);

        painel.add(new JLabel("Email"));
        txtEmail = new JTextField();
        painel.add(txtEmail);

        painel.add(new JLabel("Documento"));
        txtDocumento = new JTextField();
        painel.add(txtDocumento);

        painel.add(new JLabel("Telefone"));
        txtTelefone = new JTextField();
        painel.add(txtTelefone);

        painel.add(new JLabel("Logradouro"));
        txtLogradouro = new JTextField();
        painel.add(txtLogradouro);

        btnConsultar = new JButton("Consultar");
        btnInserir = new JButton("Inserir");
        btnAlterar = new JButton("Alterar");
        btnExcluir = new JButton("Excluir");
        btnLimpar = new JButton("Limpar");
        btnListar = new JButton("Listar");

        JPanel botoes = new JPanel();

        botoes.add(btnConsultar);
        botoes.add(btnInserir);
        botoes.add(btnAlterar);
        botoes.add(btnExcluir);
        botoes.add(btnLimpar);
        botoes.add(btnListar);


        add(painel, "Center");
        add(botoes, "South");

        configurarEventos();
    }

    private void configurarEventos() {

        btnInserir.addActionListener(e -> inserir());

        btnConsultar.addActionListener(e -> consultar());

        btnAlterar.addActionListener(e -> alterar());

        btnExcluir.addActionListener(e -> excluir());

        btnLimpar.addActionListener(e -> limparCampos());

        btnListar.addActionListener(e -> listar());
    }

    private void listar(){
        var frmLista = new FrmConsultaClientes();
        frmLista.setVisible(true);
    }

    private void inserir() {

        Cliente cli = new Cliente();
        try{
            cli.setNome(txtNome.getText());
            cli.setEmail(txtEmail.getText());
            cli.setDocumento(txtDocumento.getText());
            cli.setTelefone(txtTelefone.getText());
            cli.setLogradouro(txtLogradouro.getText());

            int retorno = dao.inserir(cli);

            if (retorno > 0) {
                JOptionPane.showMessageDialog(this,
                        "Cliente cadastrado com sucesso!");
                limparCampos();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Erro ao cadastrar cliente!", "Erro", 3);
            }
        } catch(Exception err){
            JOptionPane.showMessageDialog(this, err.getMessage(), "Verifique!", 2) ;        
        }
    }

    private void consultar() {

        if (txtCodigo.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Informe o código.");
            return;
        }

        int codigo = Integer.parseInt(txtCodigo.getText());

        Cliente cli = dao.carregar(codigo);

        if (cli.getNome() == null) {
            JOptionPane.showMessageDialog(this,
                    "Cliente não encontrado.");
            return;
        }

        txtNome.setText(cli.getNome());
        txtEmail.setText(cli.getEmail());
        txtDocumento.setText(cli.getDocumento());
        txtTelefone.setText(cli.getTelefone());
        txtLogradouro.setText(cli.getLogradouro());
    }

    private void alterar() {

        Cliente cli = new Cliente();
        try{
            cli.setCodigo(Integer.parseInt(txtCodigo.getText()));
            cli.setNome(txtNome.getText());
            cli.setEmail(txtEmail.getText());
            cli.setDocumento(txtDocumento.getText());
            cli.setTelefone(txtTelefone.getText());
            cli.setLogradouro(txtLogradouro.getText());

            int retorno = dao.alterar(cli);

            if (retorno > 0) {
                JOptionPane.showMessageDialog(this,
                        "Cliente alterado com sucesso!");
            } else {
                JOptionPane.showMessageDialog(this,
                        "Erro ao alterar cliente!");
            }
        }
        catch(Exception err){
            JOptionPane.showMessageDialog(this, err.getMessage(), "Verifique!", 2) ;  
         }    
    }

    private void excluir() {

        Cliente cli = new Cliente();

        cli.setCodigo(Integer.parseInt(txtCodigo.getText()));

        int retorno = dao.remover(cli);

        if (retorno > 0) {
            JOptionPane.showMessageDialog(this,
                    "Cliente excluído com sucesso!");
            limparCampos();
        } else {
            JOptionPane.showMessageDialog(this,
                    "Registro não encontrado.");
        }
    }

    private void limparCampos() {

        txtCodigo.setText("");
        txtNome.setText("");
        txtEmail.setText("");
        txtDocumento.setText("");
        txtTelefone.setText("");
        txtLogradouro.setText("");

        txtCodigo.requestFocus();
    }

   
}