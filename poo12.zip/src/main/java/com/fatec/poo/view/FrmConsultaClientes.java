package com.fatec.poo.view;

import com.fatec.poo.Cliente;
import com.fatec.poo.dao.ClienteDAO;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class FrmConsultaClientes extends JFrame {

    private JTable tabela;
    private DefaultTableModel modelo;
    private JButton btnAtualizar;

    private ClienteDAO dao;

    public FrmConsultaClientes() {

        dao = new ClienteDAO();

        setTitle("Lista de Clientes");
        setSize(900, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        criarComponentes();

        carregarDados();
    }

    private void criarComponentes() {

        modelo = new DefaultTableModel();

        modelo.addColumn("Código");
        modelo.addColumn("Nome");
        modelo.addColumn("Documento");
        modelo.addColumn("Telefone");
        modelo.addColumn("E-mail");
        modelo.addColumn("Logradouro");

        tabela = new JTable(modelo);

        JScrollPane scroll = new JScrollPane(tabela);

        btnAtualizar = new JButton("Atualizar");

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        painelBotoes.add(btnAtualizar);

        add(scroll, BorderLayout.CENTER);
        add(painelBotoes, BorderLayout.SOUTH);

        btnAtualizar.addActionListener(e -> carregarDados());
    }

    private void carregarDados() {

        modelo.setRowCount(0);

        List<Cliente> lista = dao.listar(0);

        for (Cliente cli : lista) {

            modelo.addRow(new Object[]{
                cli.getCodigo(),
                cli.getNome(),
                cli.getDocumento(),
                cli.getTelefone(),
                cli.getEmail(),
                cli.getLogradouro()
            });
        }
    }

  
}