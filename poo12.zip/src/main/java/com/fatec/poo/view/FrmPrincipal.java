package com.fatec.poo.view;

import javax.swing.*;
import java.awt.*;

public class FrmPrincipal extends JFrame {

    private JMenuBar menuBar;
    private JMenu menuCadastros;
    private JMenu menuConsultas;
    private JMenuItem miCliente;
    private JMenuItem miConsultaClientes;
    private JMenuItem miSair;

    public FrmPrincipal() {
        setTitle("Sistema de Controle de Clientes");
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        toFront();
        requestFocus();
       
        // Painel principal
        JPanel painel = new JPanel(new BorderLayout());
        painel.setBackground(new Color(53,152,235));
        JLabel lblTitulo = new JLabel("Sistema de Controle de Clientes", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));

        painel.add(lblTitulo, BorderLayout.CENTER);

        add(painel);

        // Barra de menu
        menuBar = new JMenuBar();

        // Menu Cadastros
        menuCadastros = new JMenu("Cadastros");

        miCliente = new JMenuItem("Clientes");

        miCliente.addActionListener(e -> {
            FrmCliente tela = new FrmCliente();
            tela.setVisible(true);
        });

        menuCadastros.add(miCliente);

        // Menu Consultas
        menuConsultas = new JMenu("Consultas");

        miConsultaClientes = new JMenuItem("Consultar Clientes");

        miConsultaClientes.addActionListener(e -> {
            FrmConsultaClientes tela = new FrmConsultaClientes();
            tela.setVisible(true);
        });

        menuConsultas.add(miConsultaClientes);

        // Menu Sistema
        JMenu menuSistema = new JMenu("Sistema");

        miSair = new JMenuItem("Sair");

        miSair.addActionListener(e -> {
            int opcao = JOptionPane.showConfirmDialog(
                    this,
                    "Deseja realmente sair?",
                    "Confirmação",
                    JOptionPane.YES_NO_OPTION);

            if (opcao == JOptionPane.YES_OPTION) {
                System.exit(0);
            }
        });

        menuSistema.add(miSair);

        // Adiciona menus à barra
        menuBar.add(menuCadastros);
        menuBar.add(menuConsultas);
        menuBar.add(menuSistema);

        setJMenuBar(menuBar);
    }

}