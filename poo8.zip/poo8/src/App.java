public class App {
    public static void main(String[] args) throws Exception {
        var v1 = new Vendedor();
        System.out.println("Fazer login");
        v1.fazerLogin("teste@teste.com", "123456");
        System.out.println(v1.retornaToken());
        System.out.println("Fazer logout");
        v1.fazerLougout();
        System.out.println(v1.retornaToken());

        var c1 = new Cliente("j@norton.net.br","234234","234234234");
         System.out.println("Fazer login");
        c1.fazerLogin("n@norton.net.br", "23423444");
        System.out.println(c1.retornaToken());

        System.out.println(fazerLogin(c1, "j@norton.net.br", "234234"));
        System.out.println(fazerLogin(v1, "j@norton.net.br", "234234"));
    }

    public static boolean fazerLogin(Autenticar o, String email, String senha){
        System.out.println("FAZER LOGIN");
        o.fazerLogin(email, senha);
        if(o.retornaToken().length()>0 && !o.retornaToken().equals("NAO AUTENTICADO")){
            return true;
        } else {
            return false;
        }
    }
}
