public interface Autenticar extends Cybersec {
    public void fazerLogin(String email, String Senha);
    public String retornaToken();
    public void fazerLougout();
}
