public class Cliente implements Autenticar{
    private String email;
    private String senha;
    private String cnpj;
    private String tk;

    

    public Cliente(String email, String senha, String cnpj) {
        this.email = email;
        this.senha = senha;
        this.cnpj = cnpj;
    }
    
    @Override
    public void fazerLogin(String email, String Senha) {
        if(this.email.equals(email) && this.senha.equals(Senha)){
            this.tk = "AUTENTICADO";
        } else {
            this.tk = "NAO AUTENTICADO!";
        }
    }
    @Override
    public String retornaToken() {
        return this.tk;
    }
    @Override
    public void fazerLougout() {
        this.tk = "NAO AUTENTICADO!";
    }

    @Override
    public void alerta(String email) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'alerta'");
    } 

    


}
