public interface Cybersec  {
    public void alerta(String email);
}
