import java.util.Base64;

public class Vendedor extends Funcionario implements Autenticar {
    private String token = "";
    @Override
    public void fazerLogin(String email, String Senha) {
        if(email.equals("teste@teste.com") && 
        Senha.equals("123456") ){
            this.token = Base64.getEncoder().encodeToString(email.getBytes());
        } else {
            this.token = "";
        }
    }
    @Override
    public String retornaToken() {
        return this.token;
    }
    @Override
    public void fazerLougout() {
       this.token = "";
    }
    @Override
    public void alerta(String email) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'alerta'");
    }

}
